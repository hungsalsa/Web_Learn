configure({
  sources: [
    source('amd', 'tinymce.lists', '../../src/main/js', mapper.hierarchical)
  ]
});